import CartList from '../components/product/CartList';

function Cart() {
  return (
    <>
      <CartList />
    </>
  );
}

export default Cart;
