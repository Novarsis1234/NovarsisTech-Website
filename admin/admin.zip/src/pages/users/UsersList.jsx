const UsersList = () => {
  return <div>UsersList</div>;
};

export default UsersList;
