function ErrorBoundary() {
  return <div>ErrorBoundary</div>;
}

export default ErrorBoundary;
